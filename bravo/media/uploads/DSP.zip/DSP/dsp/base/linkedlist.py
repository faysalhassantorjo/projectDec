class Node:
    def __init__(self,id,name,image,price,stock,model):
        self.id=id
        self.name=name
        self.image=image
        self.price=price
        self.stock=stock
        self.model=model
        self.next=None

class LinkedList:
    def __init__(self):
        self.head=None
    
    def insert(self,id,name,image,price,stock,model):
        newNode=Node(id,name,image,price,stock,model)
        if not self.head:
            self.head=newNode
        else:
            currentNode=self.head
            while currentNode.next:
                currentNode=currentNode.next
            currentNode.next=newNode
    
    def search(self,name):
        currentNode=self.head
        while currentNode:
            if currentNode.name==name:
                productInfo={
                'id':currentNode.id,
                'name':currentNode.name,
                'image':currentNode.image,
                'price':currentNode.price,
                'stock':currentNode.stock,
                'model':currentNode.model
                }
                return productInfo
            currentNode=currentNode.next
        return None

    
    def get_products(self):
        products=[]
        current=self.head

        while current:
            productInfo={
                'id':current.id,
                'name':current.name,
                 'image':current.image,
                  'price':current.price,
                'stock':current.stock,
                'model':current.model
            }
            products.append(productInfo)

            current=current.next
        
        return products