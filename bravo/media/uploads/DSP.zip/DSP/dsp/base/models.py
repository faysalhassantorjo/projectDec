from django.db import models

# Create your models here.
class Category(models.Model):
    name=models.CharField(max_length=200)
    image=models.ImageField(upload_to='media/products/',null=True,blank=True)

    @property
    def imageURL(self):
        try:
            url=self.image.url
        except:
            url=''
        return url
    
    def __str__(self):
        return self.name


class Product(models.Model):
    name=models.CharField(max_length=200)
    Category=models.ForeignKey(Category,on_delete=models.CASCADE)
    image=models.ImageField(upload_to='media/products/',null=True,blank=True)
    price=models.PositiveIntegerField(default=0)
    stock=models.PositiveIntegerField(default=0)
    brand_name=models.CharField(max_length=100,null=True,default=None)
    product_Model=models.CharField(max_length=100,null=True,default=None)

    @property
    def imageURL(self):
        try:
            url=self.image.url
        except:
            url=''
        return url
    
    def __str__(self):
        return self.name

class CartItem(models.Model):
    product=models.ForeignKey(Product,on_delete=models.CASCADE)
    quantity=models.PositiveIntegerField(default=1)


    @property
    def get_items_total(self):
        total=self.product.price*self.quantity
        return total
    
    @property
    def total_items_cart(self):
        cart_items=CartItem.objects.all()
        total=0
        for item in cart_items:
            total+=item.quantity
        return total

    @property
    def get_total(self):
        cart_items=CartItem.objects.all()
        total=0
        for item in cart_items:
            total+=(item.product.price*item.quantity)
        return total