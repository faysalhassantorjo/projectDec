from django.contrib import admin
from django.urls import path
from .views import *


urlpatterns = [
    path('',home,name='home'),
    path('product/<str:pk>/',product,name='product'),
    path('add-to-cart/', add_to_cart, name='add_to_cart'),
    path('get-cart-items/', get_cart_items, name='get_cart_items'),
    path('cart/',cart,name='cart'),
    path('search/',searchProduct,name='search'),
    path('pop',pop,name='pop'),
]
