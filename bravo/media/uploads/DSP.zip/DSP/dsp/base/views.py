from django.shortcuts import render,HttpResponse
from django.shortcuts import render,redirect
from .models import Category,Product,CartItem
from .linkedlist import LinkedList
from .stack import Stack
from django.shortcuts import get_object_or_404
from django.http import JsonResponse
import json

# Create your views here.
def home(request):
    categories=Category.objects.all()
    
    products = Product.objects.all()
    linkedList = LinkedList()

    for product in products:
        linkedList.insert(product.pk, product.name, product.imageURL,product.price,product.stock,product.product_Model)

    allProducts = linkedList.get_products()

    context = {}
    if request.method == 'POST':
        e = request.POST['q']
        name=e.lower()
        searchedProduct = linkedList.search(name)
        context = {
            'searchedProduct': searchedProduct,
            'allProducts': allProducts  
        }

        return render(request, 'base/searchResult.html', context)

    context={
        'categories':categories,
    }
    return render(request,'base/index.html',context)

def searchProduct(request):
    return HttpResponse(request,'hello')
    
        
       










def product(request,pk):
    category_wise_product={}
    category=Category.objects.get(id=pk)
    product_linkedlist=LinkedList()
    products=Product.objects.filter(Category=category)

    for product in products:
        product_linkedlist.insert(product.pk, product.name, product.imageURL,product.price,product.stock,product.product_Model)

    category_wise_product=product_linkedlist.get_products()

    # print(category_wise_product)
    cart_items=CartItem.objects.all()
    stack=Stack()
    
    
   
    for item in cart_items:
         stack.push(item)

    stack_cart=stack.display()

    for stack_item in stack_cart:
        print(stack_item.product.name)
        print(stack_item.product.price)
        print(stack_item.quantity)



    t=CartItem()

    context={
        'cartitems':cart_items,
        'category':category,
        'productList':category_wise_product,
        'total_item_carts':t.total_items_cart
    }
    for cart_item in cart_items:
        print('carts: ',cart_item.product.name,' qnty : ',cart_item.quantity ,end="\n")
    return render(request,'base/product.html',context)


def cart(request):
    
    cart_items=CartItem.objects.all().order_by('-id')
    stack=Stack()
    for item in cart_items:
         stack.push(item)

    stack_cart=stack.display()

    for stack_item in stack_cart:
        print(stack_item.product.name)
        print(stack_item.product.price)
        print(stack_item.quantity)



    
    total_cart_items=0
    total=0
    get_total=0
    for item in cart_items:
        total_cart_items+=item.quantity
        total+=(item.product.price*item.quantity)
        get_total+=item.get_total
   
    t=CartItem()

    context={
        'cartitems':stack_cart,
        'total_cart_items':total_cart_items,
        'get_total':get_total,
        'total_items_cart':t.total_items_cart
     }
    return render(request,'base/cart.html',context)


def add_to_cart(request):
    data = json.loads(request.body)
    # print(data)
    productId=data['porductId']
    product=get_object_or_404(Product,id=productId)
    cart_item,created=CartItem.objects.get_or_create(product=product)
    # print('hello')
    if not created:
        cart_item.quantity+=1
        cart_item.save()
  
    return JsonResponse({'message': 'Item added to cart successfully'})
    
def get_cart_items(request):
   
    return render(request,'base/product.html')



def pop(request):
    cart_items=CartItem.objects.all()
    stack=Stack()
    for item in cart_items:
         stack.push(item)
    
    poped_item=stack.pop()
    if poped_item!=-1:
        poped_item.delete()

    else:
        print('Your stack is empty')

    return redirect('cart')