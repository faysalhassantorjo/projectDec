from django.db import models
from django.contrib.auth.models import User
import uuid

# Create your models here.
class Service(models.Model):
    service_name=models.CharField(max_length=100)

    def __str__(self):
        return str(self.service_name)


class ServiceSection(models.Model):
    creator=models.ForeignKey(User,on_delete=models.SET_NULL,null=True)
    service_name=models.ForeignKey(Service,on_delete=models.CASCADE)
    description=models.CharField(max_length=200)
    
    def __str__(self):
        return str(self.service_name)
    
class ServiceRoom(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    service = models.ForeignKey(ServiceSection, on_delete=models.SET_NULL, null=True)
    creator = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='created_servicerooms')
    client = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='client_servicerooms')

    def __str__(self):
        return str(self.id)


class RoomChat(models.Model):
    host=models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='host')
    creator=models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='creator')
    message=models.TextField()
    roomId=models.CharField(max_length=10)

    def __str__(self) -> str:
        return self.message


    