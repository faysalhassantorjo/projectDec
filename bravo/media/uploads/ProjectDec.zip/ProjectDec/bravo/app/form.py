from django import forms
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.models import User  # Import the User model or your custom user model

class LoginForm(AuthenticationForm):
    # You can add custom fields or validation if needed
    class Meta:
        model = User  # Change User to your actual User model
        fields = ['username', 'password']
