from django.shortcuts import render,HttpResponse,redirect
from .models import Service,ServiceSection,ServiceRoom,RoomChat
from django.contrib.auth.models import User
# Create your views here.
def home(request):
    all_service=Service.objects.all()
    context={
        'all_service':all_service,
    }
    return render(request,'app/home.html',context)

def services(request,pk):
    service=Service.objects.get(id=pk)
    section=ServiceSection.objects.filter(service_name=service)
    context={
        'section':section,
        'service':service
    }
    return render(request,'app/category.html',context)

from django.contrib.auth.decorators import login_required


@login_required(login_url='login')
def createRoom(request,pk):
    service=ServiceSection.objects.get(id=pk)
    print(request.user)
    room=ServiceRoom.objects.create()
    
    room.creator=service.creator
    room.client=request.user
    room.service=service
    room.save()
    

    messages=RoomChat.objects.filter(roomId=room.id)

    
    for message in messages:
        print('message: ',message.message)
   
    context={
        'creator':room.creator,
        'service_name':room.service,
        'room_id':room.id,
        'messages':messages
    }
    return render(request,'app/room.html',context)

from .form import LoginForm
from django.contrib.auth import login as auth_login
from django.contrib.auth import logout

def login(request):
    if request.method == 'POST':
        form = LoginForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            auth_login(request, user)  # Use auth_login instead of login
            return redirect('home')
    else:
        form = LoginForm()

    return render(request, 'app/login.html', {'form': form})

def logoutV(request):
    logout(request)
    return redirect('home')

def profile(request,pk):
    user=User.objects.get(id=pk)
    services=ServiceSection.objects.filter(creator=user)

    createdRoom=ServiceRoom.objects.filter(creator=user)
    x=ServiceRoom.objects.filter(client=user)
    print(request.user)
    print(user)
    context={
        'username':user,
        'services':services,
        'your_room':createdRoom,
        'x':x
    }
    return render(request,'app/profile.html',context)

def viewRoom(request,pk):
    room=ServiceRoom.objects.get(id=pk)
    messages=RoomChat.objects.filter(roomId=room.id)

    
    for message in messages:
        print('message: ',message.message)
   
    context={
        'creator':room.creator,
        'service_name':room.service,
        'room_id':room.id,
        'messages':messages
    }
    
    return render(request,'app/room.html',context)

from django.contrib.auth.forms import UserCreationForm


def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            auth_login(request, user)  
            return redirect('/')  
    else:
        form = UserCreationForm()

    return render(request, 'app/register.html', {'form': form})