from django.urls import path,include
from .views import *

urlpatterns = [
    
    path('',home,name='home'),
    path('services/<int:pk>/',services,name='services'),
    path('services/room/<int:pk>/',createRoom,name='room'),
    path('login/',login,name='login'),
    path('logout/',logoutV,name='logout'),
    path('profile/<int:pk>/',profile,name='profile'),
    path('view-room/<str:pk>/',viewRoom,name='viewRoom'),
    path('register/', register, name='register'),
]
